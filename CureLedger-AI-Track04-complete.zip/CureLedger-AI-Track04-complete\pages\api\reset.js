export { default } from "./seed";
